﻿using System;
using System.Linq;

public static class ConvertExt
{
    static public object[] Split(string value)
    {
        const char DELIMITER = ',';

        string str = value as string;

        // remove whitespace between each of element
        str = new string(str.ToCharArray()
                            .Where(ch => !char.IsWhiteSpace(ch))
                            .ToArray());

        // remove ',', if it is found at the end.
        char[] charToTrim = { ',', ' ' };
        str = str.TrimEnd(charToTrim);

        // split by ','
        object[] temp = str.Split(DELIMITER);
        return temp;
    }

    public static float[] ToSingleArray(string value)
    {
        object[] temp = Split(value);
        float[] result = temp.Select(e => Convert.ChangeType(e, typeof(float)))
                             .Select(e => (float)e).ToArray();
        //ERROR: InvalidCastException: Cannot cast from source type to destination type.
        //float[] result = temp.Select(e => (float)e).ToArray();
        return result;
    }

    public static double[] ToDoubleArray(string value)
    {
        object[] temp = Split(value);
        double[] result = temp.Select(e => Convert.ChangeType(e, typeof(double)))
                              .Select(e => (double)e).ToArray();
        return result;
    }

    public static short[] ToInt16Array(string value)
    {
        object[] temp = Split(value);
        short[] result = temp.Select(e => Convert.ChangeType(e, typeof(short)))
                             .Select(e => (short)e).ToArray();
        return result;
    }

    public static int[] ToInt32Array(string value)
    {
        object[] temp = Split(value);
        int[] result = temp.Select(e => Convert.ChangeType(e, typeof(int)))
                            .Select(e => (int)e).ToArray();
        return result;
    }

    public static long[] ToInt64Array(string value)
    {
        object[] temp = Split(value);
        long[] result = temp.Select(e => Convert.ChangeType(e, typeof(long)))
                            .Select(e => (long)e).ToArray();
        return result;
    }

    public static string[] ToStringArray(string value)
    {
        object[] temp = Split(value);
        string[] result = temp.Select(e => Convert.ChangeType(e, typeof(string)))
                            .Select(e => (string)e).ToArray();
        return result;
    }

}