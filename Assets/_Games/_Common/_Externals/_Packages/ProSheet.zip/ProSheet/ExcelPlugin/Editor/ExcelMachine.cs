#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

internal class ExcelMachine : BaseMachine
{
    public string excelFilePath;
    public string[] SheetNames = { "" };
    public int CurrentSheetIndex
    {
        get { return currentSelectedSheet; }
        set { currentSelectedSheet = value; }
    }

    [SerializeField]
    protected int currentSelectedSheet = 0;

    [MenuItem("Assets/Create/ProSheet/Import Excel Setting")]
    public static void CreateScriptMachineAsset()
    {
        ExcelMachine inst = CreateInstance<ExcelMachine>();
        string path = CustomAssetUtility.GetUniqueAssetPathNameOrFallback(ImportSettingFilename);
        AssetDatabase.CreateAsset(inst, path);
        AssetDatabase.SaveAssets();
        Selection.activeObject = inst;
    }
}
#endif //UNITY_EDITOR
