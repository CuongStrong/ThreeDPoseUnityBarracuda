#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System;

public abstract class BaseConfigEditor<T> : Editor where T : ScriptableObject
{
    protected SerializedObject targetObject;
    protected SerializedProperty spreadsheetProp;
    protected SerializedProperty worksheetProp;
    protected SerializedProperty serializedData;

    protected GUIStyle box;
    protected bool isGUISkinInitialized = false;

    public virtual void OnEnable()
    {
        T t = (T)target;
        targetObject = new SerializedObject(t);

        spreadsheetProp = targetObject.FindProperty("SheetName");
        if (spreadsheetProp == null)
            Debug.LogError("Failed to find 'SheetName' property.");

        worksheetProp = targetObject.FindProperty("WorksheetName");
        if (worksheetProp == null)
            Debug.LogError("Failed to find 'WorksheetName' property.");

        serializedData = targetObject.FindProperty("Data");
        if (serializedData == null)
            Debug.LogError("Failed to find 'Data' member field.");
    }

    protected void InitGUIStyle()
    {
        box = new GUIStyle("box");
        box.border = new RectOffset(4, 4, 4, 4);
        box.margin = new RectOffset(3, 3, 3, 3);
        box.padding = new RectOffset(4, 4, 4, 4);
    }

    protected void DrawInspector(bool useGUIStyle = true)
    {
        EditorGUILayout.TextField(spreadsheetProp.name, spreadsheetProp.stringValue);
        EditorGUILayout.TextField(worksheetProp.name, worksheetProp.stringValue);

        if (useGUIStyle && !isGUISkinInitialized)
        {
            isGUISkinInitialized = true;
            InitGUIStyle();
        }

        if (useGUIStyle)
            GUIHelper.DrawSerializedProperty(serializedData, box);
        else
            GUIHelper.DrawSerializedProperty(serializedData);
    }

    public virtual bool Load()
    {
        throw new NotImplementedException();
    }
}
#endif //UNITY_EDITOR
