#if UNITY_EDITOR
using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class ColumnHeader
{
    public CellType type;
    public string name;
    public bool isEnable;
    public bool isArray;
    public ColumnHeader nextArrayItem;

    // used to order columns by ascending. (only need on excel-plugin)
    public int OrderNO { get; set; }
}

public class BaseMachine : ScriptableObject
{
    protected const string ImportSettingFilename = "Import Excel Setting.asset";
    protected const string DEFAULT_TEMPLATE_PATH = "Libs/ProSheet/ExcelPlugin/Templates";
    protected const string DEFAULT_CLASS_PATH = "Scripts/Sheet";
    protected const string DEFAULT_EDITOR_PATH = "Scripts/Sheet/Editor";

    public string ScriptableFilePath { get; set; }

    [SerializeField]
    private string templatePath = DEFAULT_TEMPLATE_PATH;
    public string TemplatePath
    {
        get { return templatePath; }
        set { templatePath = value; }
    }

    [SerializeField]
    private string scriptFilePath = DEFAULT_CLASS_PATH;
    public string RuntimeClassPath
    {
        get { return scriptFilePath; }
        set { scriptFilePath = value; }
    }

    [SerializeField]
    private string editorScriptFilePath = DEFAULT_EDITOR_PATH;
    public string EditorClassPath
    {
        get { return editorScriptFilePath; }
        set { editorScriptFilePath = value; }
    }

    [SerializeField]
    private string sheetName;
    public string SpreadSheetName
    {
        get { return sheetName; }
        set { sheetName = value; }
    }

    [SerializeField]
    private string workSheetName;
    public string WorkSheetName
    {
        get { return workSheetName; }
        set { workSheetName = value; }
    }

    [System.NonSerialized]
    public bool onlyCreateDataClass = false;

    [SerializeField]
    protected List<ColumnHeader> columnHeaderList;
    public List<ColumnHeader> ColumnHeaderList
    {
        get { return columnHeaderList; }
        set { columnHeaderList = value; }
    }

    public bool HasColumnHeader()
    {
        return columnHeaderList != null && columnHeaderList.Count > 0;
    }

    protected void OnEnable()
    {
        if (columnHeaderList == null)
            columnHeaderList = new List<ColumnHeader>();
    }

    public void ReInitialize()
    {
        if (string.IsNullOrEmpty(RuntimeClassPath))
            RuntimeClassPath = DEFAULT_CLASS_PATH;
        if (string.IsNullOrEmpty(EditorClassPath))
            EditorClassPath = DEFAULT_EDITOR_PATH;

        // reinitialize. it does not need to be serialized.
        onlyCreateDataClass = false;
    }
}
#endif //UNITY_EDITOR
